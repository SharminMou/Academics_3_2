#C1a
drop table if exists reporting_table;
create table reporting_table(
    reporting_id int not null auto_increment primary key,
    rating_value int,
    product_id int not null,
    category_id int,
    customer_id int not null
);

#C1b

drop procedure if exists get_top_3_products;
delimiter //
create procedure get_top_3_products()
begin
    select distinct product_id, name, average_rating
    from reporting_table, product
    where reporting_table.product_id = product.id
    order by average_rating desc
    limit 3;
end //
delimiter ;

insert into reporting_table(rating_value,product_id,category_id,customer_id)
values (4,5,3,4),(2,3,2,5),(3,2,1,2),(1,1,4,1),(5,4,5,3);
call get_top_3_products();

#C1c
drop procedure if exists get_top_2_categories;
delimiter //
create procedure get_top_2_categories ()
    begin
        select category_id,avg(rating_value) as avg_rating
        from reporting_table, category
        where reporting_table.category_id = category.id
        group by category_id
        order by avg(rating_value) desc
        limit 2;
    end //
delimiter ;

call get_top_2_categories();

#C1d

drop procedure if exists get_frequent_rater;
delimiter //
create procedure get_frequent_rater ()
    begin
        select customer.customer_id,name, count(*) as rated
        from reporting_table,customer
        where reporting_table.customer_id = customer.customer_id
        group by name
        order by count(*) desc
        limit 1;
    end //
delimiter ;

insert into customer(name, timestamp)
values ('Yalin',now()),('Defne',now()),('Yalin',now()), ('Omer',now()), ('Yalin',now());

call get_frequent_rater();

#C1f

drop procedure if exists get_top_product_by_category;

delimiter //
create procedure get_top_product_by_category(
    in category_id int
)
begin
    select category_id,product_id, avg(rating_value) as avg_rating
        from reporting_table
        where category_id = category_id
        group by product_id
        order by avg(rating_value) desc
        limit 1;
end//
delimiter ;

call get_top_product_by_category(3);

#C1g

alter table  rating add column customer_id int not null;

drop procedure if exists populate_reporting_db;

delimiter //
create procedure populate_reporting_db()
begin
    insert into reporting_table(rating_value,product_id,customer_id)
    select distinct value,product_id,customer_id
    from rating;

    update reporting_table
    set category_id = (select category_id
                       from product
                       where reporting_table.product_id = product.id);

end//
delimiter ;

call populate_reporting_db();

insert into _changelog(applied_at, created_by, filename) VALUE (now(), 'mou', '008_B1_reporting_database.sql');



