drop table if exists customer;
create table customer (
    customer_id int not null auto_increment primary key,
    name varchar(100),
    timestamp time
);

insert into _changelog(applied_at, created_by, filename) VALUE (now(), 'mou', '004_A1_create_customer_table.sql');