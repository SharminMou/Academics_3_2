drop table if exists employee;
create table employee  (
    employee_id int not null auto_increment primary key,
    product_id int not null,
    seller_id int not null,
    customer_id int not null,
    name varchar(100)
);

drop table if exists sale;
create table sale (
    sale_id int not null auto_increment primary key,
    product_id int not null,
    invoice_id int not null,
    unit_price int not null,
    count int
);

drop table if exists invoice;
create table invoice (
    invoice_id int not null auto_increment primary key,
    customer_id int not null,
    seller_id int not null,
    timestamp time
);

insert into _changelog(applied_at, created_by, filename) VALUE (now(), 'mou', '005_A2_sale_invoice_employee.sql');
