#B2a
alter table sale add column category_id int;
alter table sale add column  seller_id int;

#B2b

drop procedure if exists get_sale_per_category;
delimiter //
create procedure get_sale_per_category(
        in employee_id int
)
begin
    select category_id, sum(count) as total_sale
    from sale
        where seller_id = employee_id
        group by  category_id;
end;//
delimiter ;

insert into sale(product_id,invoice_id,count,unit_price,category_id,seller_id) values (1,4,3,6,4,7),(3,2,4,7,5,6),(4,3,4,6,5,4);

call get_sale_per_category(4);


#B2c
drop procedure if exists set_product_category;
delimiter //
create procedure set_product_category(
        in product_id int,
        in category_id int
)
begin
        update product p
        set category_id = category_id where id = product_id;

        update product p
        set category_id = category_id where id = product_id;
end;//
delimiter ;
insert into product(name, category_id) values ('nice blue shirt',7);
call set_product_category(7,4);



insert into _changelog(applied_at, created_by, filename) VALUE (now(), 'mou', '007_B2_category.sql');