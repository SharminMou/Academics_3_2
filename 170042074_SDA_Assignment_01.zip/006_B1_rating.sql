#B1a
#Already solved

#B1b
drop procedure if exists add_rating;

delimiter //
create procedure add_rating(
    in product_id int,
    in rating_value int,
    in customer_id int
)
begin
   insert into rating(product_id, value, id)
   values (product_id, rating_value, customer_id);
end;//
delimiter ;

call add_rating(1, 5, 12);


#B1c
delimiter //
create procedure avg_rating_without_join(
        in product_id int
)
begin
    select average_rating from product where product.id = product_id;
end;//
delimiter ;

call avg_rating_without_join(5);

insert into _changelog(applied_at, created_by, filename) VALUE (now(), 'mou', '006_B1_rating.sql');
